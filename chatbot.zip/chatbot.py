import random

def greeting():
    """Greets the user and introduces the chatbot."""
    print("Hi there! I'm Botty, your friendly conversational companion. What's your name?")
    name = input(">> ")
    print("Nice to meet you, " + name + "!")
    print("Ask me anything about my capabilities or share something interesting!")

def handle_question(question):
    """Handles user questions based on predefined responses and keywords."""
    responses = {
        "what can you do?": "I can answer questions, tell jokes, and chat with you. Feel free to test my abilities!",
        "are you real?": "I'm not human, but I'm here to chat and have fun with you. What makes someone real to you?",
        "where do you come from?": "I come from the vast world of data and conversations. I'm a digital friend ready to chat!",
        "what is your favorite movie?": "I love movies! One of my favorites is [insert movie title]. What's yours?",
        "tell me a joke": "Sure thing! Here's a joke: Why did the computer catch a cold? It had too many windows open!"
    }

    if question in responses:
        return responses[question]
    else:
        return "Hmm, that's an interesting question! I'm still learning, and your curiosity fuels my knowledge."

def conversation():
    """Initiates a simple conversation with the user."""
    print("What's your favorite hobby?")
    hobby = input(">> ")
    print("Oh cool! What do you enjoy about " + hobby + "?")
    print("By the way, do you have any specific questions or topics you'd like to discuss?")
    # Continue conversation based on user's responses

def farewell():
    """Bids farewell to the user."""
    print("It was great chatting with you! If you ever want to talk again, just drop by. Goodbye!")

def main():
    greeting()
    conversation()
    while True:
        question = input(">> ").lower()
        if question == "goodbye":
            farewell()
            break
        response = handle_question(question)
        print(response)

if __name__ == "__main__":
    main()
